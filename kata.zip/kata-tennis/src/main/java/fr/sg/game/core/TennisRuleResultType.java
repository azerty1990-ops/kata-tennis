package fr.sg.game.core;

public enum TennisRuleResultType {

    DEUCE, ADVANTAGE, FINISHED
}
