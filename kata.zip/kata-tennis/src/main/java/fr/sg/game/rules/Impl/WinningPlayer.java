package fr.sg.game.rules.Impl;

public enum WinningPlayer {
    NONE, PLAYER_ONE, PLAYER_TWO
}
