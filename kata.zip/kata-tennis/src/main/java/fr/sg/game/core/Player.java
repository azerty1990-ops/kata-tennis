package fr.sg.game.core;


public interface Player {
	
    boolean incrementScore();

    String getName();

    int getScore();
}
